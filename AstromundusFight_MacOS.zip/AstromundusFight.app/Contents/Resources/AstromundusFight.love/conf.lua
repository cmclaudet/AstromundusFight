--resizing screen so it is 3x the size of the background image (as we zoom in 3x more)
function love.conf(t)
    t.window.width = 768
    t.window.height = 600
end
