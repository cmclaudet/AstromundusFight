# AstromundusFight
Fighting game with characters based on Astromundus 2016 students

To run download LOVE2D engine https://love2d.org/

Place repository in folder AMfight.love

Run with command: love AMfight.love

/// CONTROLS ///

Player 1

LEFT: a

RIGHT: d

UP: w

DOWN: s

BASIC ATTACK: e

CANCEL: q

Player 2

LEFT: l

RIGHT: j

UP: i

DOWN: k

BASIC ATTACK: u

CANCEL: o

QUIT: Esc
